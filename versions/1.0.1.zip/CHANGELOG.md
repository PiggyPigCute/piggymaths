# Change Log

This is the changelog

## [1.0.1]

### Added

* ✏️ Mathematicals symbols : ⊕└ ┘┌ ┐─
* ✏️ Mathematicals functions : `dim` `max` `min` `deg` `rg` `Vect`

## [1.0.0]

### Added

* 📂 Project structure
* 📖 `piggymaths` Language Mode
* ✏️ Mathematical symbols
* ✏️ Variables
* ✏️ Numbers
* ✏️ Block boxes
* 🖼️ Language icon
* 🖼️ Extension icon
