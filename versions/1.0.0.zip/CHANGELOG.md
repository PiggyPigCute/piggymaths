# Change Log

This is the changelog

## [1.0.0]

### Added

* 📂 Structure de l'extension
* 📖 `piggymaths` Language Mode
* ✏️ Mathematical symbols
* ✏️ Variables
* ✏️ Numbers
* ✏️ Block boxes
* 🖼️ Language icon
* 🖼️ Extension icon
