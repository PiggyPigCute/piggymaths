# PiggyMaths README

PiggyMaths is an extension made to write mathematics in monospace texts.

There is a new Language Mode names `piggymaths` used on files of type `.p`, `.pig` and `.asm`

## 🕗 Changelog

Look at `CHANGELOG.md` file
